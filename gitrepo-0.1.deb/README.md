# Explanation
This package is used to create new repository on your github account with CLI.
## How To Use ?
* Just type in your terminal : `gitrepo -h` of course, you must install this package first.
* [How To Install](https://github.com/dekiakbar/LinuxShell) - Installation step.